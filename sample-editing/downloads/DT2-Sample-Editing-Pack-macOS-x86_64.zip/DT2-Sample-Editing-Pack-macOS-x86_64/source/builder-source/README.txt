Use release README.md and docs/HOW_TO.md. K�ri accepted the exact880d810f firmware on hardware on2026-11-05. Builder warning removed; firmware and generation logic unchanged.
